# Remember to use comments like this one to annotate and explain what you do.
# Make sure you have created a folder for this week, such as 'week_2' where you can upload the zip file

library(tidyverse)

cows <- read_csv("penelope22.csv")
View(cows)
mean(cows$estimate)
sd(cows$estimate)

median(*MISSING*) # This needs editing

mean(cows$female_estimate) # This needs editing
mean(cows$other_estimate) # This needs editing

sd(cows$female_estimate) # This needs editing

hist(cows$estimate)
hist(cows$estimate, breaks = *MISSING*) # This needs editing

boxplot(cows$estimate)
boxplot(cows$female_estimate)
boxplot(cows$other_estimate)
boxplot(cows$estimate, notch=TRUE)

cows %>% 
  ggplot(aes(x=identity, y=estimate)) +
  geom_boxplot(fill="azure")+
  theme_classic()

# Here is where you can practice these steps by looking at the data on:

# Immigration Estimates

# 1. Read the data into an object in RStudio

# 2. Perform some relevant statistics on columns from the data (mean, median)

# 3. Conduct some simple visualisations of the data (histogram, boxplot)




