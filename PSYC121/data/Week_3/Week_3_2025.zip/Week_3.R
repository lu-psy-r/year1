# Here's your friendly reminder that you can make notes using the comments lines (displayed in green in the script)
# Use notes to write comments to help you remember what you do and what things mean


# Make sure you run the script lines. Some students have missed the next line and the script won't play nice without it

library(tidyverse)

# What does the last line do? We can ask R to tell us more, see the next line

help(tidyverse)
help(read_csv)
help(median)

# Start by setting up a project folder for 'week 3" - details in the learnr tutorial. Then open that directory and set this as the working directory.

what_a_really_terrible_data_object_name <- read_csv(*MISSING*) # use your own data_object_name and specify the file you want to work with

# Here's code for another way to access data files: data_object_name <- read_csv(file.choose())

# Here is one way to check this looks liek the right data

View(*MISSING*)

# so now we want to explore 2-dimension Penelope data, looking at the 'estimate' score broken down by identity

aggregate(x = *MISSING*$estimate, by = list(*MISSING*$identity), FUN = mean)

# aggregate?? What's that? OK, let's ask for help (option 2 but you can use help() as well!)

?aggregate

# This time, let's try to 'group_by() to look at 2-dimensional data. The next line will need editing!

*MISSING* %>% group_by(*MISSING*) %>% summarise(mean_estimate = mean(*MISSING*))

# Dataset 2: 
# Try to find out whether salary estimates changed with region of the UK. The file is 'wages2024.csv'
# Build up commands below using what you have already done, including the following (see lab sheet as well)

new_object <- read_csv(*MISSING*) # edit to add file name and a new data object name
View(*MISSING*) # view the data object

# Dataset 3: phone time usage as a function of phone type

# read in the data
new_object <- read_csv(*MISSING*) # edit to add file name and a new data object name
View(*MISSING*) # view the data object

# YOUR TASK: build up commands below using what you have already done

# Produce a visualisation of the phone usage data as a function of the type of phone/

*data_object* %>% 
  ggplot(aes(x = *categorical_column*, y = *numerical_column*)) + 
  geom_violin()

# can you add (+) a theme to this ggplot graph?

