# Here's your friendly reminder that you can make noies using the comments lines (displayed in green in the script)
# Use notes to write comments to help you remember what you do and what things mean


# Make sure you run the script lines. Some students have missed the next line and the script won't play nice without it

library(tidyverse)

# What does the last line do? We can ask R to tell us more, see the next line

help(tidyverse)
help(read_csv)
help(median)

# Start by setting up a project folder for 'week 3" - details in the learnr tutorial. Then open that directory and set this as the working directory.


data_object_name <- read_csv("fill in") # use your own dataobject_name and specify the file you want to work with

# Here's code for another way to access data files: data_object_name <- read_csv(file.choose())

# Here is one way to check this looks liek the right data

View(*MISSING*)

# so now we want to explore 2-dimension Penelope data, looking at the 'estimate' score broken down by identity

aggregate(x = *MISSING*$estimate, by = list(*MISSING*$identity), FUN = mean)

# aggregate?? What's that? OK, let's ask for help (option 2 but you can use help() as well!)

?aggregate

# This time, let's try to 'group_by() to look at 2-dimensional data. The next line will need editing!

*MISSING* %>% group_by(*MISSING*) %>% summarise(mean_estimate = mean(*MISSING*))

options(pillar.sigfig=4)  # If you don't like the look of the tibble data readout, try ask this and then repeat the above line


# Dataset 2: 
# Try to find out whether salary estimates chnaged with region of the UK. The file is 'wages2024.csv'
# Build up commands below using what you have already done, including the following (see lab sheet as well)

glimpse(*MISSING*)

# Dataset 3: 
# What about phone time usage as a function of phone type?
# Build up commands below using what you have already done

# Finally - can you produce a visualisation of the phone usage data as a function of the type of phone/

boxplot(*data_column* ~ *category_column*)
object %>% ggplot(aes(x = *category*, y = *data*)) + geom_violin()

