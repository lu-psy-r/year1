5+5

week_1_lecture_data <- c(7,8,8,7,3,1,6,9,3,8)

mean(week_1_lecture_data)

median(week_1_lecture_data)

# we will use a library command to get a function for the mode. 
library() # use lab notes to complete this

# Note: Any text that appears after the hash character is for you to read, it is ignored by R
# Note: So it is really useful to add comments to help explain what you are doing

# Use comment lines to explain what each of the above is doing

# Can you use what you have learned above to calculate central tendency scores for dice rolling?

# More data to practice with:

# Premier league winners points (for seasons with 38 games played)
PL_points <- 
  c(82,75, 78, 79, 91, 80, 87, 83, 90, 95, 91, 89,
    87, 90, 86, 80, 89, 89, 86, 87, 81, 93, 100, 98,
    99, 86, 93, 89, 91, 84)

# mean global temperature in Fahrenheit (1990 - 2023) 
world_avg_temp <- 
  c(53.41991, 51.81992, 53.61993, 50.31994, 54.7000,  53.91996, 54.31997, 53.41998, 52.91999, 
    53.32000, 53.72001, 53.82002, 52.02003, 55.02004, 52.12005, 53.42006, 53.82007, 53.82008, 
    51.92009, 52.12010, 52.72011, 51.82012, 56.62013, 53.32014, 55.62015, 56.32016, 56.22017, 
    56.12018, 56.22019, 53.62020, 55.72021, 56.32022, 55.92023, 55.6000)


