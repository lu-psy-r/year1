
library(tidyverse)

# WAGES DATA
# Read in the data from the wages2024.csv data set 
*MISSING* <- read_csv("*MISSING") 

# Edit the missing parts here to draw a violin graph. Add new titles/captions to the graph
*MISSING* %>% 
  ggplot(aes(x = *MISSING*, y = *MISSING*)) + 
  geom_violin(fill = *MISSING*) + # add a colour here 
  *MISSING* + # add a theme
  labs(x = "title for x axis here",
       y = "title for y axis here",
       title = "main title for graph here")

# can you add a geom_boxplot() layer to this graph? (tip: use + to add layers to graphs) 

*MISSING* %>% 
  ggplot(aes(x = salary)) + 
  geom_histogram()

# try to add a "facet_wrap()" as per the instructions in the lab handbook. 


# SCREEN TIME DATA
# MISSING - add some code to read in the screentime data into an object

# Edit the missing parts here to draw a violin graph. Add new titles/captions to the graph
*MISSING* %>% 
  ggplot(aes(x = *MISSING*, fill = *MISSING*)) + 
  geom_histogram() +
  *MISSING*() + # add a theme
  labs(x = "title for x axis here",
       y = "title for y axis here",
       title = "main title for graph here") 

# let's try a density plot
*MISSING* %>% 
  ggplot(aes(x = *MISSING*, fill = *MISSING*)) + 
  geom_density(alpha = .6) + # what does alpha do? try changing the value...
  *MISSING* + # add a theme
  labs(x = "title for x axis here",
       y = "title for y axis here",
       title = "main title for graph here")

# Final exercise. Convert all the phone usage data into z scores with scale. Look at the result. What is the largest and smallest z score?
usage_z <-scale(MISSING)
usage_z_sorted <- sort(usage_z, decreasing = FALSE) # If you had to guess, what does sort() do?
print(usage_z_sorted) # This displays the object from the previous line. Does this help work out sort()?
